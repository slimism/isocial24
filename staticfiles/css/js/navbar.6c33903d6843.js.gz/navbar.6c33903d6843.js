// JavaScript to handle modal display
$(document).ready(function(){
    $("#loginButton").click(function(){
        $("#login-modal").modal('show');
    });
});